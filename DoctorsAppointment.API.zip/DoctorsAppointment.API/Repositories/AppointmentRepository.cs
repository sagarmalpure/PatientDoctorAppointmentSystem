﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using DoctorsAppointment.API.Services;
using DoctorsAppointment.API.Repositories.Interfaces;

namespace DoctorsAppointment.API.Repositories {
	public class AppointmentRepository : IAppointmentRepository {
		private readonly IConfiguration _config;

		public AppointmentRepository(IConfiguration config) {
			this._config = config;
		}
		public IDbConnection DefaultConnection {
			get {
				return new SqlConnection(_config["ConnectionStrings:DefaultConnection"]);
			}
		}
		public int BookAppointment(BookAppointment appointment) {
			try {
				using (IDbConnection dbConnection = DefaultConnection) {

					DynamicParameters parameter = new DynamicParameters();
					parameter.Add("@DoctorID", value: appointment.DoctorID, dbType: DbType.Int32, direction: ParameterDirection.Input);
					parameter.Add("@Name", value: appointment.Name, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Phone", value: appointment.Phone, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Email", value: appointment.Email, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Date", value: appointment.Date, dbType: DbType.Date, direction: ParameterDirection.Input);

					var result = dbConnection.ExecuteScalar<int>("usp_Book_Appointment", parameter, commandType: CommandType.StoredProcedure);
					return result;
				}
			}
			catch (Exception) {
				throw;
			}
		}
	}
}
