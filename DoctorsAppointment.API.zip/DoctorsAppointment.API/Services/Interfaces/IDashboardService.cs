﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;

namespace DoctorsAppointment.API.Services {
	public interface IDashboardService {
		IEnumerable<dynamic> GetListUpcomingAppointments(int doctorID);
		DoctorDetails GetDoctorDetailsByID(int doctorid);
		int TotalAppointmentByDoctorID(int doctorID);
		int TotalUpcomingAppointmentByDoctorID(int doctorID);
		int UpdateAppointmentStatus(int appointID, bool status, string comment = null);
	}
}
