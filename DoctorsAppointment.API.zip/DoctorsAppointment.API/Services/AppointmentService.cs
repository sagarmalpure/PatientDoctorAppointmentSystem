﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using DoctorsAppointment.API.Repositories;
using DoctorsAppointment.API.Repositories.Interfaces;
using Microsoft.Extensions.Configuration;

namespace DoctorsAppointment.API.Services {
	public class AppointmentService : IAppointmentService {
		private readonly IAppointmentRepository _appointmentRepository;

		public AppointmentService(IAppointmentRepository appointmentRepository) {
			_appointmentRepository = appointmentRepository ?? throw new ArgumentNullException(nameof(appointmentRepository));
		}
		public int BookAppointment(BookAppointment appointment) {
			try {
				return _appointmentRepository.BookAppointment(appointment);
			}
			catch (Exception) {
				throw;
			}
		}
	}
}
