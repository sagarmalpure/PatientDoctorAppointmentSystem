﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using FluentValidation;

namespace DoctorsAppointment.API.Validators {

	/// <summary>
	/// Add validator for PatientSignUp model
	/// </summary>
	public class LoginDetailsAddValidator : AbstractValidator<PatientSignUp> {

		public LoginDetailsAddValidator() {
			RuleFor(x => x.Name).NotEmpty().MaximumLength(30);
			RuleFor(x => x.Phone).NotEmpty().MaximumLength(12);
			RuleFor(x => x.Password).NotEmpty().MaximumLength(20);
			RuleFor(x => x.Email).NotEmpty().MaximumLength(30);			
		}
	}

	public class LoginDetailsGetValidator : AbstractValidator<LoginDetails> {
		
		public LoginDetailsGetValidator() {

			RuleFor(x => x.Email).NotEmpty().MaximumLength(30);
			RuleFor(x => x.Password).NotEmpty().MaximumLength(20);
			RuleFor(x => x.Type).NotNull().GreaterThan(0);
		}
	}
}
