﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorsAppointment.API.Models {
	public class AppointmentDetails {
		public int AppointID { get; set; }
		public int DoctorID { get; set; }
		public int PatientID { get; set; }
		public DateTime Date { get; set; }
		public int Appointment_Status { get; set; }
		public float Bill_Amount { get; set; }
		public string Bill_Status { get; set; }
		public int DoctorNotification { get; set; }
		public int PatientNotification { get; set; }
		public int FeedbackStatus { get; set; }
		public string Disease { get; set; }
		public string Progress { get; set; }
		public string Prescription { get; set; }
		public DateTime CreatedDate { get; set; }
	}

	public class Department {
		public int DeptID { get; set; }
		public string DeptName { get; set; }
		public string Description { get; set; }
		public bool IsActive { get; set; }
		public DateTime CreatedDate { get; set; }
	}
	public class BookAppointment {
		public int AppointID { get; set; }
		public int DoctorID { get; set; }
		public string Name { get; set; }
		public string Phone { get; set; }
		public string Email { get; set; }
		public DateTime Date { get; set; }
	}
}
