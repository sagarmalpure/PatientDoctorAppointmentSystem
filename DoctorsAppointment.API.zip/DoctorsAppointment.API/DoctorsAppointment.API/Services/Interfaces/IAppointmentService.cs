﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;


namespace DoctorsAppointment.API.Services
{
    public interface IAppointmentService {
        int BookAppointment(BookAppointment appointment);
    }
}
