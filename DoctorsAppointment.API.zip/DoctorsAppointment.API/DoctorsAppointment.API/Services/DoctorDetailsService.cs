﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using DoctorsAppointment.API.Repositories;
using DoctorsAppointment.API.Repositories.Interfaces;
using Microsoft.Extensions.Configuration;

namespace DoctorsAppointment.API.Services {
	public class DoctorDetailsService : IDoctorDetailsService {
		private readonly IDoctorDetailsRepository _doctorDetailsRepository;

		public DoctorDetailsService(IDoctorDetailsRepository doctorDetailsRepository) {
			_doctorDetailsRepository = doctorDetailsRepository ?? throw new ArgumentNullException(nameof(doctorDetailsRepository));
		}
		public IEnumerable<DoctorDetails> GetDoctorDetails() {
			return _doctorDetailsRepository.GetDoctorDetails();
		}
		public DoctorDetails GetDoctorDetailsByID(int doctorid) {
			return _doctorDetailsRepository.GetDoctorDetailsByID(doctorid);
		}
	}
}
