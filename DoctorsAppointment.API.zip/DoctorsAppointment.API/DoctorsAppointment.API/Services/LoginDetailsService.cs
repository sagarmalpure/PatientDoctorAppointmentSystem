﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using DoctorsAppointment.API.Repositories;
using Microsoft.Extensions.Configuration;

namespace DoctorsAppointment.API.Services {
	public class LoginDetailsService : ILoginDetailsService {
		private readonly ILoginDetailsRepository _loginDetailsRepository;

		public LoginDetailsService(ILoginDetailsRepository loginDetailsRepository) {
			_loginDetailsRepository = loginDetailsRepository ?? throw new ArgumentNullException(nameof(loginDetailsRepository));
		}
		public int GetLoginDetails(string emailid, string password, int type) {
			try {
				return _loginDetailsRepository.GetLoginDetails(emailid, password, type);
			}
			catch (Exception) {
				throw;
			}
		}
		public int SignUp(PatientSignUp record) {
			try {
				return _loginDetailsRepository.SignUp(record);
			}
			catch (Exception) {
				throw;
			}
		}
	}
}
