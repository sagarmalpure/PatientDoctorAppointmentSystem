﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using DoctorsAppointment.API.Repositories;
using DoctorsAppointment.API.Repositories.Interfaces;
using Microsoft.Extensions.Configuration;

namespace DoctorsAppointment.API.Services {
	public class DashboardService : IDashboardService {
		private readonly IDashboardRepository _dashboardRepository;

		public DashboardService(IDashboardRepository dashboardRepository)
		{
			_dashboardRepository = dashboardRepository ?? throw new ArgumentNullException(nameof(dashboardRepository));
		}
		public IEnumerable<dynamic> GetListUpcomingAppointments(int doctorID)
		{
			return _dashboardRepository.GetListUpcomingAppointments(doctorID);
		}
		public DoctorDetails GetDoctorDetailsByID(int doctorid)
		{
			return _dashboardRepository.GetDoctorDetailsByID(doctorid);
		}
		public int TotalAppointmentByDoctorID(int doctorID)
		{
			return _dashboardRepository.TotalAppointmentByDoctorID(doctorID);
		}
		public int TotalUpcomingAppointmentByDoctorID(int doctorID)
		{
			return _dashboardRepository.TotalUpcomingAppointmentByDoctorID(doctorID);
		}
		public int UpdateAppointmentStatus(int appointID, bool status, string comment = null)
		{
			return _dashboardRepository.UpdateAppointmentStatus(appointID, status, comment);
		}
	}
}
