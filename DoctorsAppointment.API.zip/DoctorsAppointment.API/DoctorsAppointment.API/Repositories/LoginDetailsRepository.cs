﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace DoctorsAppointment.API.Repositories {
	public class LoginDetailsRepository : ILoginDetailsRepository {
		private readonly IConfiguration _config;

		public LoginDetailsRepository(IConfiguration config) {
			this._config = config;
		}
	
		public int GetLoginDetails(string emailid, string password, int type) {

			try {
				using (IDbConnection con = new SqlConnection(_config["ConnectionStrings:DefaultConnection"])) {

					DynamicParameters parameter = new DynamicParameters();
					parameter.Add("@Email", value: emailid, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Password", value: password, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Type", value: type, dbType: DbType.Int32, direction: ParameterDirection.Input);

					var result = con.Query<int>("usp_Login_Credentials", parameter, commandType: CommandType.StoredProcedure).FirstOrDefault();
					return result;
				}
			}
			catch (Exception) {
				throw;
			}
		}
	
		public int SignUp(PatientSignUp record) {
			try {
				using (IDbConnection con = new SqlConnection(_config["ConnectionStrings:DefaultConnection"])) {

					DynamicParameters parameter = new DynamicParameters();
					parameter.Add("@Name", value: record.Name, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Phone", value: record.Phone, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Address", value: record.Address, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@BirthDate", value: record.Birthdate, dbType: DbType.DateTime, direction: ParameterDirection.Input);
					parameter.Add("@Gender", value: record.Gender, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Password", value: record.Password, dbType: DbType.String, direction: ParameterDirection.Input);
					parameter.Add("@Email", value: record.Email, dbType: DbType.String, direction: ParameterDirection.Input);

					var result = con.ExecuteScalar<int>("usp_Patient_Signup", parameter, commandType: CommandType.StoredProcedure);
					return result;
				}
			}
			catch (Exception) {
				throw;
			}
		}
	}
}
