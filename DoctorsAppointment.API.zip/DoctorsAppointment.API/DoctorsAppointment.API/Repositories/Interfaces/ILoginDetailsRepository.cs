﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;

namespace DoctorsAppointment.API.Repositories
{
    public interface ILoginDetailsRepository
    {
        int GetLoginDetails(string emailid, string password, int type);
        int SignUp(PatientSignUp record);
    }
}
