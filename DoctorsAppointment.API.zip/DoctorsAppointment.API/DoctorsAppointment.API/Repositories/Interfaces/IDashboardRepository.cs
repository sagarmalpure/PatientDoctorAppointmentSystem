﻿using DoctorsAppointment.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorsAppointment.API.Repositories.Interfaces {
	public interface IDashboardRepository {
		DoctorDetails GetDoctorDetailsByID(int doctorid);
		int TotalAppointmentByDoctorID(int doctorID);
		int TotalUpcomingAppointmentByDoctorID(int doctorID);
		IEnumerable<dynamic> GetListUpcomingAppointments(int doctorID);
		int UpdateAppointmentStatus(int appointID, bool status, string comment = null);
	}
}
