﻿using DoctorsAppointment.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorsAppointment.API.Repositories.Interfaces {
	public interface IDoctorDetailsRepository {
		IEnumerable<DoctorDetails> GetDoctorDetails();
		DoctorDetails GetDoctorDetailsByID(int doctorid);
	}
}
