﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using DoctorsAppointment.API.Services;
using DoctorsAppointment.API.Repositories.Interfaces;

namespace DoctorsAppointment.API.Repositories {
	public class DoctorDetailsRepository : IDoctorDetailsRepository {
		private readonly IConfiguration _config;

		public DoctorDetailsRepository(IConfiguration config) {
			this._config = config;
		}
		public IDbConnection DefaultConnection {
			get {
				return new SqlConnection(_config["ConnectionStrings:DefaultConnection"]);
			}
		}

		public IEnumerable<DoctorDetails> GetDoctorDetails() {

			try {
				using (IDbConnection dbConnection = DefaultConnection) {

					return dbConnection.Query<DoctorDetails>("usp_Get_Doctor_Details", commandType: CommandType.StoredProcedure).ToList();
				}
			}
			catch (Exception) {
				throw;
			}
		}
		public DoctorDetails GetDoctorDetailsByID(int doctorid) {
			using (IDbConnection dbConnection = DefaultConnection) {
				return dbConnection.Query<DoctorDetails>("usp_Doctor_Details_ReadByID", new { DoctorID = doctorid }, commandType: CommandType.StoredProcedure).SingleOrDefault();
			}
		}
	}
}
