﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using DoctorsAppointment.API.Models;
using Dapper;
using Microsoft.Extensions.Configuration;
using DoctorsAppointment.API.Services;
using DoctorsAppointment.API.Repositories.Interfaces;

namespace DoctorsAppointment.API.Repositories {
	public class DashboardRepository : IDashboardRepository {
		private readonly IConfiguration _config;

		public DashboardRepository(IConfiguration config)
		{
			this._config = config;
		}
		public IDbConnection DefaultConnection {
			get {
				return new SqlConnection(_config["ConnectionStrings:DefaultConnection"]);
			}
		}

		public IEnumerable<dynamic> GetListUpcomingAppointments(int doctorID)
		{

			try
			{
				using (IDbConnection dbConnection = DefaultConnection)
				{

					return dbConnection.Query<dynamic>("usp_List_Upcoming_Appointments_By_DoctorID", new { DoctorID = doctorID }, commandType: CommandType.StoredProcedure).ToList();
				}
			}
			catch (Exception)
			{
				throw;
			}
		}
		public DoctorDetails GetDoctorDetailsByID(int doctorid)
		{
			using (IDbConnection dbConnection = DefaultConnection)
			{
				return dbConnection.Query<DoctorDetails>("usp_Doctor_Details_ReadByID", new { DoctorID = doctorid }, commandType: CommandType.StoredProcedure).SingleOrDefault();
			}
		}
		public int TotalAppointmentByDoctorID(int doctorID)
		{
			using (IDbConnection dbConnection = DefaultConnection)
			{
				return dbConnection.ExecuteScalar<int>("usp_Total_Appointment_By_DoctorID", new { DoctorID = doctorID }, commandType: CommandType.StoredProcedure);
			}
		}
		public int TotalUpcomingAppointmentByDoctorID(int doctorID)
		{
			using (IDbConnection dbConnection = DefaultConnection)
			{
				return dbConnection.ExecuteScalar<int>("usp_Total_Upcoming_Appointment_By_DoctorID", new { DoctorID = doctorID }, commandType: CommandType.StoredProcedure);
			}
		}
		public int UpdateAppointmentStatus(int appointID, bool status, string comment = null)
		{
			using (IDbConnection dbConnection = DefaultConnection)
			{
				DynamicParameters parameter = new DynamicParameters();
				parameter.Add("@appointID", value: appointID, dbType: DbType.Int32, direction: ParameterDirection.Input);
				parameter.Add("@status", value: status, dbType: DbType.Boolean, direction: ParameterDirection.Input);
				parameter.Add("@comment", value: comment, dbType: DbType.String, direction: ParameterDirection.Input);
				var result = dbConnection.ExecuteScalar<int>("usp_Update_Appointments_Status", parameter, commandType: CommandType.StoredProcedure);
				return result;
			}
		}
	}
}
