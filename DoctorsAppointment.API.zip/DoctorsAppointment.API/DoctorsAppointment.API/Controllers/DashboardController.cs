﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using DoctorsAppointment.API.Services;
using DoctorsAppointment.API.Models;
using FluentValidation.AspNetCore;
using DoctorsAppointment.API.Validators;
using FluentValidation.Results;

namespace DoctorsAppointment.API.Controllers {

	[ApiExplorerSettings(IgnoreApi = false)]
	[ApiController]
	public class DashboardController : ControllerBase {

		private readonly ILogger _logger;
		private readonly IDashboardService _dashboardService;
		private readonly IConfiguration _config;

		public DashboardController(ILogger<DashboardController> logger, IDashboardService dashboardService, IConfiguration config)
		{

			_logger = logger;
			_dashboardService = dashboardService;
			_config = config;
		}

		[HttpGet("getTotalAppointment/{doctorID}")]
		public ActionResult<dynamic> TotalAppointmentByDoctorID(int doctorID)
		{
			try
			{
				var result = _dashboardService.TotalAppointmentByDoctorID(doctorID);
				return Ok(result); // Returns an OkNegotiatedContentResult
			}
			catch (Exception ex)
			{
				return NotFound(ex.Message);
			}
		}
		[HttpGet("getUpcomingAppointment/{doctorID}")]
		public ActionResult<dynamic> TotalUpcomingAppointmentByDoctorID(int doctorID)
		{
			try
			{
				var result = _dashboardService.TotalUpcomingAppointmentByDoctorID(doctorID);
				return Ok(result); // Returns an OkNegotiatedContentResult
			}
			catch (Exception ex)
			{
				return NotFound(ex.Message);
			}
		}
		[HttpGet("getListUpcomingAppointments/{doctorID}")]
		public ActionResult<IEnumerable<dynamic>> GetListUpcomingAppointments(int doctorID)
		{
			try
			{
				var result = _dashboardService.GetListUpcomingAppointments(doctorID);
				if (result == null)
				{
					return Ok("No records found"); // Returns a NotFoundResult
				}
				return Ok(result); // Returns an OkNegotiatedContentResult
			}
			catch (Exception ex)
			{
				return NotFound(ex.Message);
			}
		}
		[HttpPut("updateAppointmentStatus/{appointID}/{status}")]
		public ActionResult<dynamic> UpdateAppointmentStatus(int appointID, bool status, string comment = null)
		{
			try
			{
				var result = _dashboardService.UpdateAppointmentStatus(appointID, status, comment);
				return Ok("Appointment status updated succesfully"); // Returns an OkNegotiatedContentResult
			}
			catch (Exception ex)
			{
				return NotFound(ex.Message);
			}
		}
	}
}
