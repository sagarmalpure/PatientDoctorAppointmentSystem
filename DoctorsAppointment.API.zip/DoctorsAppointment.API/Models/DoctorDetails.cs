﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DoctorsAppointment.API.Models {
	public class DoctorDetails {
		public int DoctorID { get; set; }
		public string Name { get; set; }
		public string Gender { get; set; }
		public DateTime BirthDate { get; set; }
		public string PhoneNumber { get; set; }
		public string Address { get; set; }
		public int DeptID { get; set; }
		public string DeptName { get; set; }
		public string Description { get; set; }
		public float ChargesPerVisit { get; set; }
		public int PatientsTreated { get; set; }
		public float Rating { get; set; }
		public string Qualification { get; set; }
		public string Specialization { get; set; }
		public int Work_Experience { get; set; }
		public bool IsActive { get; set; }
		public DateTime CreatedDate { get; set; }

	}
}
