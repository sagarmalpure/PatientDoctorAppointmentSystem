﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using DoctorsAppointment.API.Services;
using DoctorsAppointment.API.Models;
using FluentValidation.AspNetCore;
using DoctorsAppointment.API.Validators;
using FluentValidation.Results;

namespace DoctorsAppointment.API.Controllers {

	[ApiExplorerSettings(IgnoreApi = false)]
	[ApiController]
	public class AppointmentController : ControllerBase {

		private readonly ILogger _logger;
		private readonly IAppointmentService _appointmentService;
		private readonly IConfiguration _config;

		public AppointmentController(ILogger<AppointmentController> logger, IAppointmentService appointmentService, IConfiguration config) {

			_logger = logger;
			_appointmentService = appointmentService;
			_config = config;
		}
		[HttpPost("bookAppointment")]
		public ActionResult<dynamic> BookAppointment([FromBody] BookAppointment appointment) {
			try {
				var result = _appointmentService.BookAppointment(appointment);
				if (result != 1) {
					return Ok("Appointment booking failed"); // Returns a NotFoundResult
				}
				return Ok("Appointment booked successfully"); // Returns an OkNegotiatedContentResult
			}
			catch (Exception ex) {
				return NotFound(ex.Message);
			}
		}
	}
}
