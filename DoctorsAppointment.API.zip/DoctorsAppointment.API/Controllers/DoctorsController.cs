﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using DoctorsAppointment.API.Services;
using DoctorsAppointment.API.Models;
using FluentValidation.AspNetCore;
using DoctorsAppointment.API.Validators;
using FluentValidation.Results;

namespace DoctorsAppointment.API.Controllers {

	[ApiExplorerSettings(IgnoreApi = false)]
	[ApiController]
	public class DoctorsController : ControllerBase {

		private readonly ILogger _logger;
		private readonly IDoctorDetailsService _doctorDetailsService;
		private readonly IConfiguration _config;

		public DoctorsController(ILogger<DoctorsController> logger, IDoctorDetailsService doctorDetailsService, IConfiguration config) {

			_logger = logger;
			_doctorDetailsService = doctorDetailsService;
			_config = config;
		}

		[HttpGet("getAllDoctors")]
		public ActionResult<IEnumerable<DoctorDetails>> GetDoctorDetails() {

			try {
				var result = _doctorDetailsService.GetDoctorDetails();
				if (result == null) {
					return Ok("No records found"); // Returns a NotFoundResult
				}
				return Ok(result); // Returns an OkNegotiatedContentResult
			}
			catch (Exception ex) {
				return NotFound(ex.Message);
			}
		}
		[HttpGet("getDoctorDetails/{doctorid}")]
		public ActionResult<DoctorDetails> GetDoctorDetailsByID(int doctorid) {

			try {
				var result = _doctorDetailsService.GetDoctorDetailsByID(doctorid);
				if (result == null) {
					return Ok("No records found"); // Returns a NotFoundResult
				}
				return Ok(result); // Returns an OkNegotiatedContentResult

			}
			catch (Exception ex) {
				return NotFound(ex.Message);
			}
		}
	}
}
