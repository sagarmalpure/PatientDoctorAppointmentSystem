﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using DoctorsAppointment.API.Services;
using DoctorsAppointment.API.Models;
using FluentValidation.AspNetCore;
using DoctorsAppointment.API.Validators;
using FluentValidation.Results;

namespace DoctorsAppointment.API.Controllers {

	[ApiExplorerSettings(IgnoreApi = false)]
	[ApiController]
	public class AuthenticationController : ControllerBase {

		private readonly ILogger _logger;
		private readonly ILoginDetailsService _loginDetailsService;
		private readonly IConfiguration _config;

		/// <summary>
		/// Initializes a new instance of the <see cref="AuthenticationController"/> class.
		/// </summary>
		/// <param name="logger">The logger.</param>
		/// <param name="loginDetailsService">The loginDetailsService.</param>
		/// <param name="config">The config service.</param>
		public AuthenticationController(ILogger<AuthenticationController> logger, ILoginDetailsService loginDetailsService, IConfiguration config) {

			_logger = logger;
			_loginDetailsService = loginDetailsService;
			_config = config;
		}

	
		[HttpGet("signIn/{emailid}/{password}/{type}")]
		public ActionResult<dynamic> LoginToApp(string emailid, string password, int type) {

			try {
				var result = _loginDetailsService.GetLoginDetails(emailid, password, type);
				if (result != 1) {
					return Ok(); // Returns a NotFoundResult
				}
				return Ok(); // Returns an OkNegotiatedContentResult
			}
			catch (Exception ex) {
				return NotFound(ex.Message);
			}
		}
		[HttpPost("patientSignUp")]
		public ActionResult<dynamic> PatientSignUp([FromBody] PatientSignUp record) {

			try {
				var validator = new LoginDetailsAddValidator();

				ValidationResult validationResults = validator.Validate(record);

				if (!validationResults.IsValid) {

					return NotFound(validationResults);
				}
				else {
					var result = _loginDetailsService.SignUp(record);
					if (result != 1) {
						return Ok("No records added"); // Returns a NotFoundResult
					}
					return Ok("Record added Successfully"); // Returns an OkNegotiatedContentResult
				}
			}
			catch (Exception ex) {
				return NotFound(ex.Message);
			}
		}
	}
}
